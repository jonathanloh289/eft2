package com.eracom.OBM;
/* This intarfece has Standard constants */
public interface Custom
{
	public static final int customer = 0;							/*0 is for standard	*/
	public static final int MAX_PIN_STRING_SIZE = 30;
	public static final int MIN_PIN_STRING_SIZE = 4;

	/*Max and min modulus size in bits */
	public static final int MAX_RSA_MODULUS_SIZE_IN_BITS	= 1280;
	public static final int MIN_RSA_MODULUS_SIZE_IN_BITS	= 768;		

		
}