package com.eracom.OBM;

public class OAEPEncodedMsgException extends Exception
{
  /**
   * Constructors for OAEPEncodedMsgException
   */
     static final long serialVersionUID = -2740153767582114766L;
  public OAEPEncodedMsgException()
  {
    super();
  }

  public OAEPEncodedMsgException(String msg)
  {
    super(msg);
  }
}

