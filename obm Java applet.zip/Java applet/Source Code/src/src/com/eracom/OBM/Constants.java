package com.eracom.OBM;
/* This intarfece contains constats used in the applet */
public interface Constants
{

	/* Following declaration are used to identify a customer. 
	If custom code for new customer is written the new customer should be declared here.
	All classes that uses customer specific code should implement this interface */
	public static final int STANDARD = 0;
	public static final int UOB = 1;
	
	/*	Error Codes : used in the applet. 
		If some customer uses some custom error code with different value,
		declare it in customer specific interface (Custom.java)
	*/
	public static final int ERR_NO_ERROR = 0;

	public static final int ERR_INVALID_PIN_LENGTH = 10;
	public static final int ERR_INVALID_PIN = 11;

	public static final int ERR_INVALID_PIN_BLOCK = 20;
	public static final int ERR_INVALID_RANDOM_NUMBER_LENGTH = 21;
	public static final int ERR_INVALID_RANDOM_NUMBER = 22;
	public static final int ERR_OLD_NEW_PASSWORD_SAME = 23;
	public static final int ERR_INVALID_HASH = 27;
	
	public static final int ERR_INVALID_PIN_MESSAGE = 30;
	public static final int ERR_INVALID_PIN_MESSAGE_LENGTH = 31;

	public static final int ERR_INVALID_RSA_KEY_LENGTH = 41;
	public static final int ERR_INVALID_RSA_KEY = 42;
	
	

}