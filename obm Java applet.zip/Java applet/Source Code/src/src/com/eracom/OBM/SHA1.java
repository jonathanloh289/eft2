package com.eracom.OBM;

public class SHA1
{
  /* Note: constant and variable names match those used in SHA-1
     Specification FIPS PUB 180-1 */

  // constants
  private static final int MAX_HASH_SIZE_IN_BYTES = 20;
  private static final int NUM_OF_BITS_PER_BLOCK = 512;
  private static final int NUM_OF_BITS_PER_BYTE = 8;
  private static final int NUM_OF_BITS_PER_WORD = 32;
  private static final int NUM_OF_BITS_FOR_MSG_LENGTH = 64;
  private static final int MSG_LENGTH_BYTE_ARRAY_OFFSET = 60;
  private static final int NUM_OF_BYTES_PER_BLOCK = 64;
  private static final int NUM_OF_BYTES_PER_WORD = 4;
  private static final int NUM_OF_WORDS_PER_BLOCK = 16;
  private static final int MAX_NUM_OF_PROCESS_STEPS = 80;
  private static final int PROCESSING_STEP_19 = 19;
  private static final int PROCESSING_STEP_39 = 39;
  private static final int PROCESSING_STEP_59 = 59;
  private static final int PROCESSING_STEP_79 = 79;
  
  private static final int K1 = 0x5A827999;
  private static final int K2 = 0x6ED9EBA1;
  private static final int K3 = 0x8F1BBCDC;
  private static final int K4 = 0xCA62C1D6;
  
  // variables
  
  private int A, B, C, D, E;			// first set of 32-bit word buffers
  private int H0, H1, H2, H3, H4;		// second set of 32-bit word buffers
  private int temp;
  private int[] W = new int[MAX_NUM_OF_PROCESS_STEPS];		// processing array
  private int[] M = new int[NUM_OF_WORDS_PER_BLOCK];		// 16 word message block

  private int numOfIntegralBlocksInMsg;
  private int numOfPaddedMsgBlocks;
  private byte[] hashByteArray = new byte[MAX_HASH_SIZE_IN_BYTES];
  private int[] lastPaddedMsgBlock = new int[NUM_OF_WORDS_PER_BLOCK];
  private int[] secondLastPaddedMsgBlock;
  
  // constructor
  public SHA1() 
  {
  	/* initialise word buffers */
  	H0 = 0x67452301;
  	H1 = 0xEFCDAB89;
  	H2 = 0x98BADCFE;
  	H3 = 0x10325476;
  	H4 = 0xC3D2E1F0;
  }
  
  public byte[] doHash(byte[] inputMsgByteArray, int inputMsgLengthInBytes)
  {
  	int blockCount, t, tempWord;
  	
  	padInputMessage(inputMsgByteArray, inputMsgLengthInBytes);

  	for (blockCount = 1; blockCount <= numOfPaddedMsgBlocks; blockCount++)
  	{
  	  if (blockCount <= numOfIntegralBlocksInMsg)
  	  {
  	    convertByteArrayToBlock(M, inputMsgByteArray, (blockCount - 1));
  	  }
  	  else if (blockCount == numOfPaddedMsgBlocks)		// get last padded block
  	  {
  	    System.arraycopy(lastPaddedMsgBlock, 0, M, 0, NUM_OF_WORDS_PER_BLOCK);
  	  }
  	  else				// get second last padded block
  	  {
  	    System.arraycopy(secondLastPaddedMsgBlock, 0, M, 0, NUM_OF_WORDS_PER_BLOCK);
  	  }
    	  
  	  System.arraycopy(M, 0, W, 0, NUM_OF_WORDS_PER_BLOCK);
  	  
  	  for (t = NUM_OF_WORDS_PER_BLOCK; t < MAX_NUM_OF_PROCESS_STEPS; t++)
  	  {
  	  	tempWord = W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16];
  	  	W[t] = rotateWordLeft(tempWord, 1);
  	  }
  	  
  	  A = H0;
  	  B = H1;
  	  C = H2;
  	  D = H3;
  	  E = H4;
  	  
  	  for (t = 0; t <= PROCESSING_STEP_79; t++)
  	  {
  	    if (t >= 0 && t <= PROCESSING_STEP_19)
  	    {
  	  	  temp = rotateWordLeft(A, 5) + ((B & C) | (~B & D)) + E + W[t] + K1;
  	    }
  	    else if (t > PROCESSING_STEP_19 && t <= PROCESSING_STEP_39)
  	    {
  	  	  temp = rotateWordLeft(A, 5) + (B ^ C ^ D) + E + W[t] + K2;
  	    }
  	    else if (t > PROCESSING_STEP_39 && t <= PROCESSING_STEP_59)
  	    {
  	  	  temp = rotateWordLeft(A, 5) + ((B & C) | (B & D) | (C & D)) + E + W[t] + K3;
  	    }
  	    else
  	    {
  	  	  temp = rotateWordLeft(A, 5) + (B ^ C ^ D) + E + W[t] + K4;
  	    }

  	  	E = D;
  	  	D = C;
  	  	C = rotateWordLeft(B, 30);
  	  	B = A;
  	  	A = temp;
  	  }
  	  
  	  H0 = H0 + A;
  	  H1 = H1 + B;
  	  H2 = H2 + C;
  	  H3 = H3 + D;
  	  H4 = H4 + E;
  	}
  	
  	convertIntToByteArray(H0, hashByteArray, 0);
  	convertIntToByteArray(H1, hashByteArray, 4);
  	convertIntToByteArray(H2, hashByteArray, 8);
  	convertIntToByteArray(H3, hashByteArray, 12);
  	convertIntToByteArray(H4, hashByteArray, 16); 	
  	return hashByteArray;
  }
  
  public void padInputMessage(byte[] inputMsgByteArray, int inputMsgLengthInBytes)
  {
  	int inputMsgLengthInBits, remainingBytesInMsg, remainingBitsInMsg;
  	int lastMsgBlockOffset;
    byte[] paddedMsgByteArray = new byte[NUM_OF_BYTES_PER_BLOCK];;
  	
  	inputMsgLengthInBits = inputMsgLengthInBytes * NUM_OF_BITS_PER_BYTE; 	
  	numOfIntegralBlocksInMsg = inputMsgLengthInBytes / NUM_OF_BYTES_PER_BLOCK;
  	lastMsgBlockOffset = numOfIntegralBlocksInMsg * NUM_OF_BYTES_PER_BLOCK;
  	remainingBytesInMsg = inputMsgLengthInBytes - lastMsgBlockOffset;
  	remainingBitsInMsg = remainingBytesInMsg * NUM_OF_BITS_PER_BYTE;
  	numOfPaddedMsgBlocks = numOfIntegralBlocksInMsg + 1;
  	
  	fillByteArray(paddedMsgByteArray, 0);
  	System.arraycopy(inputMsgByteArray, lastMsgBlockOffset, paddedMsgByteArray, 0, remainingBytesInMsg);
  	paddedMsgByteArray[remainingBytesInMsg] = (byte) 0x80;			// add 1 to end of message

  	if (remainingBitsInMsg > (NUM_OF_BITS_PER_BLOCK - NUM_OF_BITS_FOR_MSG_LENGTH - 1))
  	{
  	  secondLastPaddedMsgBlock = new int[NUM_OF_WORDS_PER_BLOCK];
  	  convertByteArrayToBlock(secondLastPaddedMsgBlock, paddedMsgByteArray, 0);
  	  fillByteArray(paddedMsgByteArray, 0);
  	  convertIntToByteArray(inputMsgLengthInBits, paddedMsgByteArray, MSG_LENGTH_BYTE_ARRAY_OFFSET);
  	  convertByteArrayToBlock(lastPaddedMsgBlock, paddedMsgByteArray, 0);
  	  numOfPaddedMsgBlocks++;
  	}
  	else
  	{
  	  convertIntToByteArray(inputMsgLengthInBits, paddedMsgByteArray, MSG_LENGTH_BYTE_ARRAY_OFFSET);
  	  convertByteArrayToBlock(lastPaddedMsgBlock, paddedMsgByteArray, 0);
  	}
  	
  	return;
  }
  
  private int rotateWordLeft(int inputWord, int shiftBitCount)
  {
  	int shiftedWord;
  	
  	shiftedWord = (inputWord << shiftBitCount) | 
  	              (inputWord >>> (NUM_OF_BITS_PER_WORD - shiftBitCount));
  	              
  	return shiftedWord;
  }
  
  private void convertByteArrayToBlock(int[] outputBlock, byte[] byteArray, int blockOffset)
  {
  	int arrayOffset, wordCount, byteCount, wordOffset, tempWord;
  	
  	arrayOffset = blockOffset * NUM_OF_BYTES_PER_BLOCK;

  	for (wordCount = 0; wordCount < NUM_OF_WORDS_PER_BLOCK; wordCount++)
  	{
  	  wordOffset = arrayOffset + wordCount * NUM_OF_BYTES_PER_WORD;  	  
  	  outputBlock[wordCount] = convertByteArrayToInt(byteArray, wordOffset);
  	} 	
  	return;
  }
    
  private int convertByteArrayToInt(byte[] byteArray, int arrayOffset)
  {
  	int tempWord, outputWord;
  	
  	tempWord = (int) byteArray[arrayOffset] & 0x000000FF;
  	outputWord  = tempWord << 24;
  	tempWord = (int) byteArray[arrayOffset + 1] & 0x000000FF;
  	outputWord  = outputWord | (tempWord << 16);
  	tempWord = (int) byteArray[arrayOffset + 2] & 0x000000FF;
  	outputWord  = outputWord | (tempWord << 8);
  	tempWord = (int) byteArray[arrayOffset + 3] & 0x000000FF;
  	outputWord  = outputWord | tempWord;
  	return outputWord;
  }
  
  private void convertIntToByteArray(int inputWord, byte[] byteArray, int arrayOffset)
  {
  	byteArray[arrayOffset] = (byte) (inputWord >>> 24);
  	byteArray[arrayOffset + 1] = (byte) (inputWord >>> 16);
  	byteArray[arrayOffset + 2] = (byte) (inputWord >>> 8);
  	byteArray[arrayOffset + 3] = (byte) inputWord;  	
  	return;
  }
  
  private void fillByteArray(byte[] byteArray, int fillCharacter)
  {
  	int index, byteArrayLength;
  	
  	byteArrayLength = byteArray.length;
  	
  	for (index = 0; index < byteArrayLength; index++)
  	{  		
 	  byteArray[index] = (byte) fillCharacter;
  	}  		
    return;
  }
}

