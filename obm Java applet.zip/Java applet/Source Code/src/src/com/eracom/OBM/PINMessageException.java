package com.eracom.OBM;

public class PINMessageException extends Exception
{
  /**
   * Constructor for PINMessageException
   */
  static final long serialVersionUID = -2740153767582114766L;
  public PINMessageException()
  {
    super();
  }

  /**
   * Constructor for PINMessageException
   */
  public PINMessageException(String msg)
  {
    super(msg);
  }
}

