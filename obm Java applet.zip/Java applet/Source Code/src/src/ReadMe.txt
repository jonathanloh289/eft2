Compilation:

1) Install nmake.
2) Install JDK/JRE.

To compile standard appet:
a) run command 'nmake' on .\src directory.
b) run command 'nmake jar' to create jar file.

To compile custom UOB applet:
a) run command 'nmake UOB' on .\src directory.
b) run command 'nmake uob_jar' to create jar file.


